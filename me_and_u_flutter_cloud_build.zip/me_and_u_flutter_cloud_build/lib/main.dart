import 'package:flutter/material.dart';

void main() => runApp(const MeAndUApp());

class MeAndUApp extends StatelessWidget {
  const MeAndUApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'Me and u Business Link',
    debugShowCheckedModeBanner: false,
    theme: ThemeData(colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xff0757a6)), useMaterial3: true),
    home: const ShopHome(),
  );
}

class ShopHome extends StatefulWidget { const ShopHome({super.key}); @override State<ShopHome> createState()=>_ShopHomeState(); }
class _ShopHomeState extends State<ShopHome> {
  final search = TextEditingController();
  int cart = 0;
  final items = const ['Toyota Corolla Brake Pads','Honda Civic Oil Filter','Nissan Engine Mount','Hyundai Headlight'];
  @override Widget build(BuildContext context) {
    final shown = items.where((x)=>x.toLowerCase().contains(search.text.toLowerCase())).toList();
    return Scaffold(
      appBar: AppBar(title: const Text('Me and u Business Link'), backgroundColor: const Color(0xff0757a6), foregroundColor: Colors.white, actions:[IconButton(onPressed:()=>showDialog(context:context,builder:(_)=>AlertDialog(title:const Text('Demo cart'),content:Text('$cart item(s) in cart'),actions:[TextButton(onPressed:()=>Navigator.pop(context),child:const Text('Close')]))),icon:const Icon(Icons.shopping_cart)]) ,
      body: ListView(padding:const EdgeInsets.all(16),children:[
        Container(padding:const EdgeInsets.all(20),decoration:BoxDecoration(color:const Color(0xff0757a6),borderRadius:BorderRadius.circular(16)),child:const Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('AUTO SPARE PARTS MARKETPLACE',style:TextStyle(color:Colors.white70)),SizedBox(height:8),Text('Find parts. Connect suppliers. Save money.',style:TextStyle(color:Colors.white,fontSize:22,fontWeight:FontWeight.bold))]),
        const SizedBox(height:16),TextField(controller:search,onChanged:(_)=>setState(()=>{}),decoration:const InputDecoration(prefixIcon:Icon(Icons.search),hintText:'Search spare parts',border:OutlineInputBorder())),
        const SizedBox(height:16),const Text('Popular spare parts',style:TextStyle(fontSize:20,fontWeight:FontWeight.bold)),
        ...shown.map((name)=>Card(child:ListTile(leading:const CircleAvatar(child:Icon(Icons.settings)),title:Text(name),subtitle:const Text('Price: Request quotation'),trailing:IconButton(icon:const Icon(Icons.add_shopping_cart),onPressed:()=>setState(()=>cart++)))) ,
        const SizedBox(height:16),const Text('Supplier connection',style:TextStyle(fontSize:20,fontWeight:FontWeight.bold)),const Text('Demo version • Orders and payments are not connected yet.'),
      ]),
      bottomNavigationBar:const NavigationBar(selectedIndex:0,destinations:[NavigationDestination(icon:Icon(Icons.home),label:'Home'),NavigationDestination(icon:Icon(Icons.search),label:'Search'),NavigationDestination(icon:Icon(Icons.receipt_long),label:'Orders'),NavigationDestination(icon:Icon(Icons.person),label:'Account')]),
    );
  }
}
