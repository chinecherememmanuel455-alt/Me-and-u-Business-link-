ME AND U BUSINESS LINK — PHONE-ONLY CLOUD APK BUILD

This is a demo Flutter app. It is not yet connected to a live database, customer accounts, payments, or real orders.

GitHub upload:
- Create a repository named me-and-u-business-link.
- Upload the CONTENTS of this project folder to the repository root (not the enclosing folder).
- Ensure pubspec.yaml, lib/main.dart, and .github/workflows/build-apk.yml are at the repository root.
- Open GitHub Actions, select Build Android APK, and tap Run workflow.
- After the run succeeds, open it and download the artifact named me-and-u-business-link-apk.
- Extract the artifact ZIP; install app-debug.apk on Android (allow installs from your file manager when prompted).
